# Competitive Landscape — Local News Aggregators

## Platform Comparison

| Feature | Google News | Apple News | Bing News | SmartNews | Flipboard |
|---|---|---|---|---|---|
| **Platform** | Android/iOS/Web | iOS/macOS only | Web/Windows | Android/iOS | Android/iOS/Web |
| **Local News** | ✅ Dedicated section, geolocation | ✅ Limited local section | ⚠️ Basic location news | ✅ Local tab | ⚠️ Limited |
| **Personalization** | ✅ Deep — location + interest + behavior | ✅ Strong | ⚠️ Basic | ✅ Strong | ✅ Interest-based |
| **Publisher Support** | ✅ GNI + Showcase (paid licensing) | ✅ Apple News+ revenue sharing | ❌ Minimal | ⚠️ SmartNews Ads | ⚠️ Limited |
| **AI Integration** | ✅ AI Overviews (2024+) | ⚠️ Limited | ✅ Copilot integration | ⚠️ Basic | ❌ None |
| **Multi-language** | ✅ 38 languages, 60+ regions | ⚠️ Limited regions | ✅ Multiple languages | ⚠️ Japan, US, Germany | ✅ Multiple |
| **Open to All Publishers** | ✅ Automated discovery | ❌ Invite-only for Apple News+ | ✅ Via Bing Webmaster | ✅ Submission-based | ✅ RSS-based |
| **Revenue to Publishers** | ✅ News Showcase licensing | ✅ Subscription revenue share | ❌ Traffic only | ⚠️ Ad revenue share | ❌ Traffic only |

## Google News Competitive Advantages for Local News

1. **Scale** — largest user base means more data for local personalization
2. **Cross-product integration** — Search, Maps, Assistant, YouTube, Discover all feed into one local signal
3. **GNI** — No competitor invests in local journalism at Google's scale
4. **Automatic publisher discovery** — No manual barriers to inclusion
5. **Android dominance** — Pre-installed Google News on Android gives massive default user base

## Key Differentiator

Google News is the only platform that:
- Automatically discovers local publishers without manual submission
- Invests $300M+ in local journalism through GNI
- Integrates local news across 6+ different product surfaces (Search, Maps, News, Discover, Assistant, YouTube)
