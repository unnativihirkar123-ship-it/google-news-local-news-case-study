# Google News — Evolution Timeline (2002–2026)

| Year | Milestone |
|------|-----------|
| 2001 | Krishna Bharat conceptualizes Google News in response to 9/11 information overload |
| 2002 | Google News launches in beta (September 2002) — automated aggregation, no human editors |
| 2006 | Localized editions launch across multiple countries and languages |
| 2010 | Google News for mobile introduced — early local news push |
| 2013 | Major redesign — card-based UI, personalization features introduced |
| 2014 | Monitoring 50,000+ news sources globally confirmed |
| 2018 | Google News completely redesigned — "For You", "Headlines", "Following", "Newsstand" sections |
| 2018 | Google News Initiative (GNI) launched with $300M commitment to support journalism |
| 2019 | Google News Showcase announced — paid licensing program for publishers |
| 2020 | News Showcase begins rolling out internationally |
| 2021 | AI-powered "Full Coverage" feature shows multiple perspectives on local stories |
| 2022 | GNI expands local publisher support programs globally |
| 2023 | 1,500+ copyright licensing agreements signed through News Showcase |
| 2024 | Publisher Center manual submission pathway closed (April 2024) |
| 2024 | AI Overviews launched in US Google Search — impacts news discovery |
| 2025 | Full transition to automatically-generated publication pages (March 2025) |
| 2025 | "Preferred Sources" feature launched — users select which sources appear more often |
| 2026 | Ongoing expansion of multilingual local news, AI summary features, GNI programs |
